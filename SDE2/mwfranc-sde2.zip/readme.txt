ARCHIVE CONTENTS
1. sde2.pro - source code containing all SDE2 predicates
2. sde1.log - ASCII log file showing 2 sample uses of each of the four
                required functions for SDE2.

PLEDGE
On my honor I have neither given nor received aid on this exam.
